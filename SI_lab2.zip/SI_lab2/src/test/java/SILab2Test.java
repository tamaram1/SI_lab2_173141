import org.junit.Test;

import static org.junit.Assert.*;

public class SILab2Test {

    @Test
    public void MultipleCondtition() {


    }

    @Test
    public void EveryStatement() {

    }

}
